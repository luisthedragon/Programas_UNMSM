
package Ordenamientos_Y_Busquedas;

public class Main {
    
    
    
    public static void main(String[] args){
        OrdFrame frame= new OrdFrame();
        frame.setVisible(true);
    }
    
    
}
